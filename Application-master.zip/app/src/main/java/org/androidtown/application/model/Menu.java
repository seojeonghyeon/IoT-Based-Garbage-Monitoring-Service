package org.androidtown.application.model;

/**
 * Created by MinWoo on 2017-11-01.
 */

public class Menu {
    private String menu;
    private String price;

    public String getMenu() {
        return menu;
    }

    public void setMenu(String menu) {
        this.menu = menu;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
