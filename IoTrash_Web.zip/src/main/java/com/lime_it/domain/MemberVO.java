package com.lime_it.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class MemberVO {

	private String user_ID;
	private String user_Password;
	private String user_Recognize;
	private String regdate;
	
	//사용자의 정보를 출력
	public String toString(){
		return user_ID + "님, 어서오세요! 가입 일자  : " + regdate;
	}
}
