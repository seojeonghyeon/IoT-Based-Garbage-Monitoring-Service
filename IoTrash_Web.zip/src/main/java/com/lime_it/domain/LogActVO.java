package com.lime_it.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class LogActVO {
	private String act_Number;
	private String act_Content;
	public String toString(){
		return act_Number + " : " + act_Content;
	}
}
