package com.lime_it.domain;

import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class DeleteVO {
	@Size(min=1, max=20, message="Year must between 1-20 chars")
	private String user_ID;
	
	@Size(min=1, max=20, message="Year must between 1-20 chars")
	private String artik_ID;
}
