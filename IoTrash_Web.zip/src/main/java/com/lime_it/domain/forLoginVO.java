package com.lime_it.domain;

import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
public class forLoginVO {
	@Size(min=1, max=20, message="Year must between 1-20 chars")
	private String user_ID;
	@Size(min=1, max=20, message="Year must between 1-20 chars")
	private String user_Password;
}
