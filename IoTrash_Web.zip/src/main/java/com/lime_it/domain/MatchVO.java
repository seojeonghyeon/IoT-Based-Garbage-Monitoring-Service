package com.lime_it.domain;

import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class MatchVO {
	
	@Size(min=1, max=40, message="Year must between 1-40 chars")
	private String user_ID;
	
	@Size(min=1, max=40, message="Year must between 1-40 chars")
	private String artik_ID;
	
	@Size(min=1, max=40, message="Year must between 1-40 chars")
	private String trash_Location;
	
	public String toString(){
		return user_ID + "의 쓰레기통은 " + artik_ID + " 정도 채워져 있으며 " + trash_Location + "에 위치합니다.";
	}
	
}
