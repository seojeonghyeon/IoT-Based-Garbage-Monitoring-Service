package com.lime_it.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class LogArtikVO {
			private String id;
			private String artik_ID;
			private String act_Time;
			private String act_Number;
			
			public String toString(){
				return artik_ID + " : (" + act_Time + ") -> " + act_Number;
			}
}
