package com.lime_it.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class LogUserVO {
		private String id;
		private String user_Recognize;
		private String act_Time;
		private String act_Number;
		public String toString(){
			return user_Recognize + " : (" + act_Time + ") -> " + act_Number;
		}
}
