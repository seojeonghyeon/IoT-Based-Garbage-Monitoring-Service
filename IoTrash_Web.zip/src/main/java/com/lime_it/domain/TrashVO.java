package com.lime_it.domain;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class TrashVO {
		private String artik_ID;
		private String trash_Amount;
		private String led_id;
		private String trash_Location;
		
		//쓰레기통의 간단 정보 출력
		public String toString(){
			return artik_ID + "의 쓰레기통은 " 
		+ trash_Amount + " 정도 채워져 있으며 " + led_id + "색입니다.";
		}
}
