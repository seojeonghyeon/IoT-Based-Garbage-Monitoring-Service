package com.lime_it.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class Member_TrashVO {
	private String id;
	private String user_Recognize;
	private String artik_ID;
	private String trash_Location;
	
	//쓰레기통의 위치를 출력
	public String toString(){
		return artik_ID + "의 위치 : " + trash_Location;
	}
}
