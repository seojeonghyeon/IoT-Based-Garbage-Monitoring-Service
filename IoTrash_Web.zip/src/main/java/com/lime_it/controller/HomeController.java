package com.lime_it.controller;

import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lime_it.domain.DeleteVO;
import com.lime_it.domain.MatchVO;
import com.lime_it.domain.MemberVO;
import com.lime_it.domain.TrashVO;
import com.lime_it.domain.forLoginVO;
import com.lime_it.service.DeleteMatchServiceImpl;
import com.lime_it.service.JsonServiceImpl;
import com.lime_it.service.LocationBringServiceImpl;
import com.lime_it.service.LoginServiceImpl;
import com.lime_it.service.MatchUserTrashServiceImpl;
import com.lime_it.service.NewMemberServiceImpl;
import com.lime_it.service.TokenSaveService;
import com.lime_it.service.UserLogServiceImpl;
import com.lime_it.service.UserTrashBringServiceImpl;
import com.lime_it.service.TrashBringService;
import com.lime_it.service.TrashLogServiceImpl;

@Controller
public class HomeController {

private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
@Autowired
UserLogServiceImpl LogService;

@Autowired
TokenSaveService tokenService;

@Autowired
NewMemberServiceImpl NewMemberService;

@Autowired
UserTrashBringServiceImpl TrashBringService;

@Autowired
LoginServiceImpl LoginService;

@Autowired
JsonServiceImpl JsonService;

@Autowired
TrashBringService TrashService;

@Autowired
UserTrashBringServiceImpl UserTrashService;

@Autowired
TrashLogServiceImpl TrashLogService;

@Autowired
MatchUserTrashServiceImpl matchService;

@Autowired
DeleteMatchServiceImpl DeleteService;

@Autowired
LocationBringServiceImpl locationBringService;

@RequestMapping(value = "/")
public String home(Locale locale, Model model) {
	return "login";
}


@RequestMapping(value = "/regist", method = RequestMethod.POST)
public String webRegist(HttpServletRequest request, Model model, @Valid forLoginVO loginVO, BindingResult result) throws Exception {
	if(result.hasErrors()){
		System.out.println("======Form data does not validated");
		List<ObjectError> errors = result.getAllErrors();
		for(ObjectError error : errors){
			System.out.println(error.getDefaultMessage());
		}
		return "regist";
	}
	if(loginVO.getUser_ID().equals("") || loginVO.getUser_Password().equals("")){
		logger.info("ID or Password is null");
		return "error";
	}else{
		System.out.println(loginVO.getUser_ID()+"    "+loginVO.getUser_Password());
		int returnValue = NewMemberService.newRegist(loginVO.getUser_ID(), loginVO.getUser_Password());
		if(returnValue == 0){
			logger.info("regist success");
			MemberVO vo = LoginService.updateUser(loginVO.getUser_ID());
			System.out.println(vo);
			LogService.recodLog(vo.getUser_Recognize(), "Regist");
			return "login";
		}else{
			logger.info("already exist");
			return "regist";
		}
	}
}

@RequestMapping(value = "/webLogin", method = RequestMethod.POST)
public String webLogin(HttpServletRequest request, HttpServletResponse response, Model model, @RequestParam("user_ID") String user_ID, @RequestParam("user_Password") String user_Password) throws Exception {
	if(request.getParameter("login") != null){
		if(user_ID.equals("") || user_Password.equals("")){
			logger.info("ID or Password is null");
			return "login";
		}else{
			if(LoginService.webLogin(user_ID, user_Password).equals("100")){
				logger.info("WebLogin success");
				MemberVO memberVO = LoginService.updateUser(user_ID);
				List<TrashVO> listTrashVO = TrashBringService.TrashBring(memberVO.getUser_Recognize());
				List<TrashVO> returnlistTrashVO = locationBringService.locationBring(memberVO, listTrashVO);
				request.setAttribute("memebr", memberVO);
				request.setAttribute("trashlist", returnlistTrashVO);
				LogService.recodLog(memberVO.getUser_Recognize(), "WebLogin");
				return "mainPage";
			}else{
				logger.info("WebLogin fail");
				return "login";
			}
		}
	}else if(request.getParameter("regist") != null){
		logger.info("regist page");
		model.addAttribute("loginVO", new forLoginVO());
		return "regist";
	}else{
		logger.info("error");
		return "error";
	}
	
}

@RequestMapping(value = "/appLogin", method = RequestMethod.POST)
@ResponseBody
public String appLogin(HttpServletRequest request, @RequestParam("user_ID") String user_ID, @RequestParam("user_Password") String user_Password) throws Exception {
	if(LoginService.webLogin(user_ID, user_Password).equals("100")){
		logger.info("AppLogin success");
		MemberVO vo = LoginService.updateUser(user_ID);
		LogService.recodLog(vo.getUser_Recognize(), "AppLogin");
		return "100";
	}else{
		logger.info("AppLogin fail");
		return "200";
	}
}
@RequestMapping(value = "/postTrash", method = RequestMethod.GET)
@ResponseBody
public String postTrash(HttpServletRequest request, @RequestParam("artik_ID") String artik_ID, @RequestParam("trash_Amount") String trash_Amount, @RequestParam("led_Color") String led_Color) throws Exception {
	TrashLogService.recodLog(artik_ID, "postTrash");
	if(TrashService.checkTrash(artik_ID)==false){
		System.out.println("value nono");
		TrashService.insertTrash(artik_ID, trash_Amount, led_Color);
	}else{
		System.out.println("value yes");
		TrashService.updateTrash(artik_ID, trash_Amount, led_Color);
	}
	if(led_Color.equals("3")){
		
		UserTrashService.forPushAlarm(artik_ID);
	}
	return "100";
}

@RequestMapping(value = "/postApp", method = RequestMethod.POST)
public String postApp(HttpServletRequest request, Model model, @RequestParam("user_ID") String user_ID) throws Exception {
	MemberVO memberVO = LoginService.updateUser(user_ID);
	LogService.recodLog(memberVO.getUser_Recognize(), "postApp");
	List<TrashVO> listTrashVO = TrashBringService.TrashBring(memberVO.getUser_Recognize());
	List<TrashVO> returnlistTrashVO = locationBringService.locationBring(memberVO, listTrashVO);
	model.addAttribute("JsonList", JsonService.TrashList(returnlistTrashVO));
	return "AppPost";
}

@RequestMapping(value = "/postToken", method = RequestMethod.POST)
@ResponseBody
public String postToken(HttpServletRequest request, Model model, @RequestParam("user_ID") String user_ID, @RequestParam("user_Token") String user_Token) throws Exception {
	MemberVO memberVO = LoginService.updateUser(user_ID);
	LogService.recodLog(memberVO.getUser_Recognize(), "postToken");
	if(tokenService.TrashSave(memberVO, user_Token)==true){
		return "100";
	}else{
		return "200";
	}
}

@RequestMapping(value = "/addTrash", method = RequestMethod.GET)
public String addTrash(HttpServletRequest request, Model model, @RequestParam("user_ID") String user_ID)  {
	model.addAttribute("matchVO", new MatchVO());
	model.addAttribute("user_ID", user_ID);
	return "addTrash";
}

@RequestMapping(value = "/addTrash-process", method = RequestMethod.POST)
public String addTrashProcess(HttpServletRequest request, Model model, @Valid MatchVO matchVO, BindingResult result) throws Exception {
	if(result.hasErrors()){
		System.out.println("======Form data does not validated");
		List<ObjectError> errors = result.getAllErrors();
		for(ObjectError error : errors){
			System.out.println(error.getDefaultMessage());
		}
		logger.info("AddProcess : String error");
		return "addTrash";
	}else{
		if(matchService.insertMatchData(matchVO)){
			logger.info("AddProcess : DB is save");
			return "close";
		}else{
			logger.info("AddProcess : DB is not save");
			return "addTrash";
		}
	}
}

@RequestMapping(value = "/deleteTrash", method = RequestMethod.GET)
public String deleteTrash(HttpServletRequest request, Model model, @RequestParam("user_ID") String user_ID) throws Exception {
	model.addAttribute("deleteVO", new DeleteVO());
	model.addAttribute("user_ID", user_ID);
	return "deleteTrash";
}

@RequestMapping(value = "/deleteTrash-process" , method = RequestMethod.POST)
public String deleteTrashProcess(HttpServletRequest request, Model model, @Valid DeleteVO deleteVO, BindingResult result) throws Exception {
	if(result.hasErrors()){
		System.out.println("======Form data does not validated");
		List<ObjectError> errors = result.getAllErrors();
		for(ObjectError error : errors){
			System.out.println(error.getDefaultMessage());
		}
		logger.info("AddProcess : String error");
		return "addTrash";
	}else{
		if(DeleteService.deleteMatchValue(deleteVO)){
			logger.info("AddProcess : DB is delete");
			return "close";
		}else{
			logger.info("AddProcess : DB is not delete");
			return "addTrash";
		}
		
	}
}


}
