package com.lime_it.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.lime_it.domain.PushalarmVO;

@Repository
public class PushalarmDAOImpl {

	private JdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		System.out.println("Okay1");
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public String getPushalarmRecognizes(String user_Token) {
		String sqlStatement = "select * "
				+ "from tbl_pushalarm "
				+ "where user_Token = ?";
		try{
		return jdbcTemplate.queryForObject(sqlStatement, new Object[]{user_Token},
				new RowMapper<String>() {
				public String mapRow(ResultSet rs, int rowNum) throws SQLException {
					String result = rs.getString("user_Recognize");
					return result;
				}
			}
		);
		} catch (EmptyResultDataAccessException e) {
			return "";
		}
	}

	public String getPushalarmToken(String user_Recognize) {
		String sqlStatement = "select * "
				+ "from tbl_pushalarm "
				+ "where user_Recognize = ?";
		try{
		return jdbcTemplate.queryForObject(sqlStatement, new Object[]{user_Recognize},
				new RowMapper<String>() {
				public String mapRow(ResultSet rs, int rowNum) throws SQLException {
					String result = rs.getString("user_Token");
					return result;
				}
			}
		);
		} catch (EmptyResultDataAccessException e) {
			return "";
		}
	}

	public boolean insertPushalarmValue(PushalarmVO vo){
		String user_Recognize = vo.getUser_Recognize();
		String user_Token = vo.getUser_Token();
		String sqlStatement = "insert into tbl_pushalarm "
				+ "(user_Token, user_Recognize) values (?, ?)";
		return (jdbcTemplate.update(sqlStatement, new Object[]{user_Token, user_Recognize}) == 1);
	}

}
