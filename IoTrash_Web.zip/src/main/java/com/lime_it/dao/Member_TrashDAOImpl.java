package com.lime_it.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.lime_it.domain.DeleteVO;
import com.lime_it.domain.MatchVO;
import com.lime_it.domain.Member_TrashVO;

@Repository
public class Member_TrashDAOImpl  {

	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public List<String> getMatchingRecognizes(String artik_ID) {
		String sqlStatement = "select * "
				+ "from tbl_matching "
				+ "where artik_ID = ?";
		return jdbcTemplate.query(sqlStatement, new Object[]{artik_ID},
				new RowMapper<String>() {
				public String mapRow(ResultSet rs, int rowNum) throws SQLException {
					return rs.getString("user_Recognize");
				}
			}
		);
	}
	
	public List<Member_TrashVO> getMatchingArtikValue(String user_Recognize) {
		String sqlStatement = "select * "
				+ "from tbl_matching "
				+ "where user_Recognize = ?";
		return jdbcTemplate.query(sqlStatement, new Object[]{user_Recognize},
				new RowMapper<Member_TrashVO>() {
				public Member_TrashVO mapRow(ResultSet rs, int rowNum) throws SQLException {
					Member_TrashVO vo = new Member_TrashVO();
					vo.setArtik_ID(rs.getString("artik_ID"));
					vo.setId(rs.getString("id"));
					vo.setTrash_Location(rs.getString("trash_Location"));
					vo.setUser_Recognize(rs.getString("user_Recognize"));
					return vo;
				}
			}
		);
	}
	
	public Member_TrashVO getMatchingArtikValueEach(String user_Recognize, String artik_ID) {
		String sqlStatement = "select * "
				+ "from tbl_matching "
				+ "where user_Recognize = ? and artik_ID = ?";
		try{
		return jdbcTemplate.queryForObject(sqlStatement, new Object[]{user_Recognize, artik_ID},
				new RowMapper<Member_TrashVO>() {
				public Member_TrashVO mapRow(ResultSet rs, int rowNum) throws SQLException {
					Member_TrashVO vo = new Member_TrashVO();
					vo.setArtik_ID(rs.getString("artik_ID"));
					vo.setId(rs.getString("id"));
					vo.setTrash_Location(rs.getString("trash_Location"));
					vo.setUser_Recognize(rs.getString("user_Recognize"));
					return vo;
				}
			}
		);
		} catch (EmptyResultDataAccessException e) {
			Member_TrashVO Exvo = new Member_TrashVO();
			Exvo.setArtik_ID("");
			return Exvo;
		}
	}
	
	public boolean insertMatchingValue(MatchVO vo, String user_Recognize){
		String artik_ID = vo.getArtik_ID();
		String trash_Location = vo.getTrash_Location();
		String sqlStatement = "insert into tbl_matching "
				+ "(user_Recognize, trash_Location, artik_ID) "
				+ "values (?, ?, ?)";
		return (jdbcTemplate.update(sqlStatement, new Object[]{user_Recognize, trash_Location, artik_ID}) == 1);
	}
	
	public boolean deleteMatchingValue(DeleteVO vo, String user_Recognize){
		String artik_ID = vo.getArtik_ID();
		String sqlStatement = "delete from tbl_matching "
				+ "where user_Recognize = ? and artik_ID = ?";
		return (jdbcTemplate.update(sqlStatement, new Object[]{user_Recognize, artik_ID}) == 1);
	}

}
