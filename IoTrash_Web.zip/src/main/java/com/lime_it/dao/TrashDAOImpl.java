package com.lime_it.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import com.lime_it.domain.TrashVO;

@Repository
public class TrashDAOImpl {

	private JdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public String getLedID(String led_id) {
		String sqlStatement = "select artik_ID "
				+ "from tbl_trash "
				+ "where led_id = ?";
		try{
		return jdbcTemplate.queryForObject(sqlStatement, new Object[] { led_id }, new RowMapper<String>() {
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				String result = rs.getString("artik_ID");
				return result;
			}
		});
		} catch (EmptyResultDataAccessException e) {
			return "";
		}
	}

	public TrashVO getArtikData(String artik_ID) {
		String sqlStatement = "select * "
				+ "from tbl_trash "
				+ "where artik_ID = ?";
		try{
		return jdbcTemplate.queryForObject(sqlStatement, new Object[]{artik_ID},
				new RowMapper<TrashVO>() {
				public TrashVO mapRow(ResultSet rs, int rowNum) throws SQLException {
					TrashVO vo = new TrashVO();
					vo.setArtik_ID(rs.getString("artik_ID"));
					vo.setLed_id(rs.getString("led_id"));
					vo.setTrash_Amount(rs.getString("trash_Amount"));
					vo.setTrash_Location("");
					return vo;
				}
			}
		);
		} catch (EmptyResultDataAccessException e) {
			TrashVO vo = new TrashVO();
			vo.setArtik_ID("1");
			return vo;
		}
	}
	
	public int getArtikIT(String artik_ID) {
		String sqlStatement = "select count(*) "
				+ "from tbl_trash "
				+ "where artik_ID = ?";
		return jdbcTemplate.queryForObject(sqlStatement, new Object[] { artik_ID }, Integer.class);
		} 
	
	public boolean insertArtikValue(TrashVO vo){
		String artik_ID = vo.getArtik_ID();
		String led_id = vo.getLed_id();
		String trash_Amount = vo.getTrash_Amount();
		
		String sqlStatement = "insert into tbl_trash "
				+ "(artik_ID, trash_Amount, led_id) "
				+ "values (?, ?, ?)";
		
		return (jdbcTemplate.update(sqlStatement, new Object[]{artik_ID, trash_Amount, led_id}) == 1);
	}

	public boolean updateArtikValue(TrashVO vo) {
		String artik_ID = vo.getArtik_ID();
		String led_id = vo.getLed_id();
		String trash_Amount = vo.getTrash_Amount();
		String sqlStatement = "update tbl_trash "
				+ "set trash_Amount = ?, led_id = ? "
				+ "where artik_ID = ?";
		return (jdbcTemplate.update(sqlStatement, new Object[]{trash_Amount, led_id, artik_ID}) == 1);
	}

}
