package com.lime_it.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import com.lime_it.domain.LogActVO;
import com.lime_it.domain.LogArtikVO;
import com.lime_it.domain.LogUserVO;

@Repository
public class LogDAOImpl{

private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public List<LogUserVO> getLogDataUser(String user_Recognize) {
		String sqlStatement = "select id, user_Recognize, act_Time, act_Number "
				+ "from tbl_logforuser "
				+ "where user_Recognize = ?";
		return jdbcTemplate.query(sqlStatement, new Object[]{user_Recognize},
				new RowMapper<LogUserVO>() {
				public LogUserVO mapRow(ResultSet rs, int rowNum) throws SQLException {
					LogUserVO vo = new LogUserVO();
					vo.setId(rs.getString("id"));
					vo.setAct_Number(rs.getString("act_Number"));
					vo.setAct_Time(rs.getString("act_Time"));
					vo.setUser_Recognize(rs.getString("user_Recognize"));
					return vo;
				}
			}
		);
	}
	
	public List<LogArtikVO> getLogDataArtik(String artik_ID) {
		String sqlStatement = "select id, artik_ID, act_Time, act_Number "
				+ "from tbl_logforartik "
				+ "where artik_ID = ?";
		return jdbcTemplate.query(sqlStatement, new Object[]{artik_ID},
				new RowMapper<LogArtikVO>() {
				public LogArtikVO mapRow(ResultSet rs, int rowNum) throws SQLException {
					LogArtikVO vo = new LogArtikVO();
					vo.setAct_Number(rs.getString("act_Number"));
					vo.setAct_Time(rs.getString("act_Time"));
					vo.setArtik_ID(rs.getString("artik_ID"));
					vo.setId(rs.getString("id"));
					return vo;
				}
			}
		);
	}

	public boolean insertLogforuserValue(LogUserVO vo){
		String act_Number = vo.getAct_Number();
		String user_Recognize = vo.getUser_Recognize();
		
		String sqlStatement = "insert into tbl_logforuser "
				+ "(user_Recognize, act_Number) "
				+ "values (?, ?)";
		return (jdbcTemplate.update(sqlStatement, new Object[]{user_Recognize, act_Number}) == 1);
	}
	
	public boolean insertLogforartikValue(LogArtikVO vo){
		String act_Number = vo.getAct_Number();
		String artik_ID = vo.getArtik_ID();
		String sqlStatement = "insert into tbl_logforartik "
				+ "(artik_ID, act_Number) "
				+ "values ( ?, ?)";
		return (jdbcTemplate.update(sqlStatement, new Object[]{artik_ID, act_Number}) == 1);
	}
	
	public List<LogActVO> getActUser() {
		String sqlStatement = "select * "
				+ "from tbl_actforuser";
		return jdbcTemplate.query(sqlStatement, 
				new RowMapper<LogActVO>() {
				public LogActVO mapRow(ResultSet rs, int rowNum) throws SQLException {
					LogActVO vo = new LogActVO();
					vo.setAct_Content(rs.getString("act_Content"));
					vo.setAct_Number(rs.getString("act_Number"));
					return vo;
				}
			}
		);
	}
	
	public List<LogActVO> getActArtik() {
		String sqlStatement = "select act_Number, act_Content "
				+ "from tbl_actforartik";
		return jdbcTemplate.query(sqlStatement, 
				new RowMapper<LogActVO>() {
				public LogActVO mapRow(ResultSet rs, int rowNum) throws SQLException {
					LogActVO vo = new LogActVO();
					vo.setAct_Content(rs.getString("act_Content"));
					vo.setAct_Number(rs.getString("act_Number"));
					return vo;
				}
			}
		);
	}
	
	public boolean insertActforuserValue(LogActVO vo){
		String act_Content = vo.getAct_Content();
		String sqlStatement = "insert into tbl_actforuser "
				+ "(act_Content) "
				+ "values (?)";
		return (jdbcTemplate.update(sqlStatement, new Object[]{act_Content}) == 1);
	}
	
	public boolean insertActforartikValue(LogActVO vo){
		String act_Content = vo.getAct_Content();
		
		String sqlStatement = "insert into tbl_actforartik "
				+ "(act_Content) "
				+ "values (?)";
		return (jdbcTemplate.update(sqlStatement, new Object[]{act_Content}) == 1);
	}

}
