package com.lime_it.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import com.lime_it.domain.MemberVO;


@Repository
public class MemberDAOImpl{

	private JdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		System.out.println("Okay1");
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public String getMemberLogin(String user_ID) {
		String sqlStatement = "select * "
				+ "from tbl_user "
				+ "where user_ID = ?";
		try {
		return jdbcTemplate.queryForObject(sqlStatement, new Object[]{user_ID},
				new RowMapper<String>() {
				public String mapRow(ResultSet rs, int rowNum) throws SQLException {
					String user_Password = rs.getString("user_Password");
						return user_Password;
				}
			}
		);
		} catch (EmptyResultDataAccessException e) {
			return "300";
		}
	}
	
	public MemberVO getMember(String user_ID) {
		String sqlStatement = "select * "
				+ "from tbl_user "
				+ "where user_ID = ?";
		try {
		return jdbcTemplate.queryForObject(sqlStatement, new Object[]{user_ID},
				new RowMapper<MemberVO>() {
				public MemberVO mapRow(ResultSet rs, int rowNum) throws SQLException {
					MemberVO vo = new MemberVO();
					vo.setRegdate(rs.getString("regdate"));
					vo.setUser_ID(rs.getString("user_ID"));
					vo.setUser_Password(rs.getString("user_Password"));
					vo.setUser_Recognize(rs.getString("user_Recognize"));
					return vo;
				}
			}
		);
		} catch (EmptyResultDataAccessException e) {
			return new MemberVO();
		}
	}

	public boolean insertUserMember(MemberVO vo){
		String user_ID = vo.getUser_ID();
		String user_Password = vo.getUser_Password();
		String user_Recognize = vo.getUser_Recognize();
		String sqlStatement = "insert into tbl_user "
				+ "(user_ID, user_Password, user_Recognize) "
				+ "values (?, ?, ?)";
		return (jdbcTemplate.update(sqlStatement, new Object[]{user_ID, user_Password, user_Recognize}) == 1);
	}
}
