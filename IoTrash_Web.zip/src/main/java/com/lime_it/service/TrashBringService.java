package com.lime_it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lime_it.dao.TrashDAOImpl;
import com.lime_it.domain.TrashVO;

@Service
public class TrashBringService {
	@Autowired
	TrashDAOImpl dao;
	
	public boolean checkTrash(String artik_ID){
		int number = dao.getArtikIT(artik_ID);
		System.out.println(artik_ID);
		System.out.println(number);
		if(number==0){
			//no value
			return false;
		}else{
			//value yes
			return true;
		}
	}
	
	public boolean insertTrash(String artik_ID, String trash_Amount, String led_Color){
		TrashVO vo = new TrashVO();
		vo.setArtik_ID(artik_ID);
		if(led_Color.equals("1")){
			vo.setLed_id("1");
		}else if(led_Color.equals("2")){
			vo.setLed_id("2");
		}else{
			vo.setLed_id("3");
		}
		vo.setTrash_Amount(trash_Amount);
		vo.setTrash_Location("");
		return dao.insertArtikValue(vo);
	}
	
	public boolean updateTrash(String artik_ID, String trash_Amount, String led_Color){
		TrashVO vo = new TrashVO();
		vo.setArtik_ID(artik_ID);
		if(led_Color.equals("1")){
			vo.setLed_id("1");
		}else if(led_Color.equals("2")){
			vo.setLed_id("2");
		}else{
			vo.setLed_id("3");
		}
		vo.setTrash_Amount(trash_Amount);
		vo.setTrash_Location("");
		return dao.updateArtikValue(vo);
	}
}
