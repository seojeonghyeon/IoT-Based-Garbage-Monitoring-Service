package com.lime_it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lime_it.dao.PushalarmDAOImpl;
import com.lime_it.domain.MemberVO;
import com.lime_it.domain.PushalarmVO;

@Service
public class TokenSaveService {
	
	@Autowired
	PushalarmDAOImpl dao;
	
	public boolean TrashSave(MemberVO vo, String Token){
		PushalarmVO alarmvo = new PushalarmVO();
		alarmvo.setUser_Recognize(vo.getUser_Recognize());
		alarmvo.setUser_Token(Token);
		System.out.println(alarmvo.getUser_Recognize());
		System.out.println(alarmvo.getUser_Token());
		if(dao.getPushalarmToken(vo.getUser_Recognize()).equals("")){
			return dao.insertPushalarmValue(alarmvo);
		}else{
			return false;
		}
	}
	
}
