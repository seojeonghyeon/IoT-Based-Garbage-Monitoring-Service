package com.lime_it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lime_it.dao.MemberDAOImpl;
import com.lime_it.domain.MemberVO;


@Service
public class NewMemberServiceImpl {

	@Autowired
	MemberDAOImpl dao;
	
	MemberVO vo;
	
	public int newRegist(String user_ID, String user_Password) throws Exception {
		if(dao.getMemberLogin(user_ID).equals("300")){
			vo = new MemberVO();
			vo.setUser_ID(user_ID);
			vo.setUser_Password(user_Password);
			vo.setUser_Recognize(recognizeCreate(user_ID));
			vo.setRegdate("");
			dao.insertUserMember(vo);
			return 0;
		}else{
			return 1;
		}
	}
	public String recognizeCreate(String user_ID){
		int NumB = (int) (Math.random() * 9999) + 1;
		String Code = (String)user_ID+NumB;
		System.out.println("User Recognize Code Create : " + Code);
		return Code;
	}

}
