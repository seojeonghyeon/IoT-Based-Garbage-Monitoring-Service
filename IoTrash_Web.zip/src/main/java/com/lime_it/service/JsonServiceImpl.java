package com.lime_it.service;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.lime_it.domain.TrashVO;

@Service
public class JsonServiceImpl {
	public JSONArray TrashList(List<TrashVO> voList){
		/*String returnValue = "[";
		
		int i=0;
		for(TrashVO vo : voList){
			returnValue=returnValue+"{";
			returnValue=returnValue+"\"artik_ID\":\""+vo.getArtik_ID()+"\"";
			returnValue=returnValue+",\"led_id\":\""+vo.getLed_id()+"\"";
			returnValue=returnValue+",\"trash_Amount\":\""+vo.getTrash_Amount()+"\"";
			returnValue=returnValue+",\"trash_Location\":\""+vo.getTrash_Location()+"\"}";
			if((voList.size()-1)==i){
				i=0;
				returnValue=returnValue+"]";
			}else{
				i++;
				returnValue=returnValue+"],[";
			}
		}
		return returnValue;*/
		
		JSONArray arrJson = new JSONArray();
		for(TrashVO vo : voList){
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("artik_ID", vo.getArtik_ID());
			jsonObject.put("led_id", vo.getLed_id());
			jsonObject.put("trash_Amount", vo.getTrash_Amount());
			jsonObject.put("trash_Location", vo.getTrash_Location());
			arrJson.put(jsonObject);
		}
		return arrJson;
	}
}
