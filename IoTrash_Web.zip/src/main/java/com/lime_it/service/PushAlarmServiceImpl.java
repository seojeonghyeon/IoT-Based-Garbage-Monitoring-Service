package com.lime_it.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lime_it.dao.PushalarmDAOImpl;

@Service
public class PushAlarmServiceImpl {

	@Autowired
	private PushalarmDAOImpl dao;
	
	private final static String AUTH_KEY_FCM = "AAAAmwcNl6I:APA91bFm1mU_eR1B-hnFKvY7VZbAVGGoPegvX8wW2hhAIBSNvEUsoJ-CzBO6nQormmcfOAcc_SwWXdfyz9Jlg42yaq3bUG3jXpTgwMZj6NJE4LCRAmIZerQcSF3_Lr2wF1rztxZfcQa4";
	private final static String API_URL_FCM = "https://fcm.googleapis.com/fcm/send";
	static String msg = "휴지통이 가득찼습니다!";
	
	public void pushAlarm(String user_Recognize, String trash_Location) throws Exception {
		pushFCMNotification(dao.getPushalarmToken(user_Recognize), trash_Location);
	}
	
	public static void pushFCMNotification(String userDeviceIdKey, String trash_Location) throws Exception {
        String authKey = AUTH_KEY_FCM; // You FCM AUTH key
        String FMCurl = API_URL_FCM;

        URL url = new URL(FMCurl);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        conn.setUseCaches(false);
        conn.setDoInput(true);
        conn.setDoOutput(true);
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "key=" + authKey);
        conn.setRequestProperty("Content-Type", "application/json");

        JSONObject json = new JSONObject();
        JSONObject info = new JSONObject();
        msg=msg+":"+trash_Location;
        info.put("body", msg ); // Notification body
        json.put("notification", info);
        json.put("to", userDeviceIdKey.trim());
        System.out.println(json);
        try(OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream())){
            wr.write(json.toString());
            wr.flush();
        }catch(Exception e){
        }
        if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
            throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
        }
        BufferedReader br = new BufferedReader(new InputStreamReader(
                (conn.getInputStream())));
        String output;
        System.out.println("Output from Server .... \n");
        while ((output = br.readLine()) != null) {
            System.out.println(output);
        }
        conn.disconnect();
    }

}
