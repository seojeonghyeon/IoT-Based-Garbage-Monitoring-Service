package com.lime_it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lime_it.dao.Member_TrashDAOImpl;
import com.lime_it.domain.MatchVO;
import com.lime_it.domain.MemberVO;
import com.lime_it.domain.Member_TrashVO;

@Service
public class MatchUserTrashServiceImpl {

	@Autowired
	private Member_TrashDAOImpl matchDAO;
	
	@Autowired
	LoginServiceImpl LoginService;
	
	public boolean insertMatchData(MatchVO matchVO) throws Exception{
		MemberVO memberVO = LoginService.updateUser(matchVO.getUser_ID());
		Member_TrashVO vo = matchDAO.getMatchingArtikValueEach(memberVO.getUser_Recognize(), matchVO.getArtik_ID());
		if(vo.getArtik_ID().equals("")){
			matchDAO.insertMatchingValue(matchVO, memberVO.getUser_Recognize());
			return true;
		}else{
			return false;
		}
		
	}
	
	public String BringtrashLocation(String user_Recognize, String artik_ID){
		Member_TrashVO vo = matchDAO.getMatchingArtikValueEach(user_Recognize, artik_ID);
		return vo.getTrash_Location();
	}
	
	
}
