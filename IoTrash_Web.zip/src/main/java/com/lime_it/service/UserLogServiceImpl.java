package com.lime_it.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.lime_it.dao.LogDAOImpl;
import com.lime_it.domain.LogActVO;
import com.lime_it.domain.LogUserVO;

@Service
public class UserLogServiceImpl {

	@Autowired
	LogDAOImpl dao;
	
	LogUserVO vo;
	
	public void recodLog(String user_Recognize, String actValue) throws Exception {
		System.out.println(user_Recognize);
		System.out.println(actValue);
		String act_Number = null;
		List<LogActVO> listActVO = null;
		try {
			listActVO = dao.getActUser();
		} catch (Exception e) {
			e.printStackTrace();
		}
		for(LogActVO ActVO : listActVO){
			if(ActVO.getAct_Content().equals(actValue))
				act_Number = ActVO.getAct_Number();
		}
		vo = new LogUserVO();
		vo.setAct_Number(act_Number);
		vo.setAct_Time("");
		vo.setId("");
		vo.setUser_Recognize(user_Recognize);
		dao.insertLogforuserValue(vo);
	}

	public List<LogUserVO> bringLog(String user_Recognize) throws Exception {
		return dao.getLogDataUser(user_Recognize);
	}

}
