package com.lime_it.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lime_it.dao.Member_TrashDAOImpl;
import com.lime_it.domain.MemberVO;
import com.lime_it.domain.Member_TrashVO;
import com.lime_it.domain.TrashVO;

@Service
public class LocationBringServiceImpl {
	@Autowired
	private Member_TrashDAOImpl matchDAO;
	
	@Autowired
	LoginServiceImpl LoginService;
	
	public List<TrashVO> locationBring(MemberVO memberVO, List<TrashVO> listTrashVO){
		System.out.println(listTrashVO.size());
		List<TrashVO> returnlistTrashVO = new ArrayList<TrashVO>();
		for(TrashVO vo : listTrashVO){
			Member_TrashVO member_trashVO = matchDAO.getMatchingArtikValueEach(memberVO.getUser_Recognize(), vo.getArtik_ID());
			vo.setTrash_Location(member_trashVO.getTrash_Location());
			returnlistTrashVO.add(vo);
		}
		return returnlistTrashVO;
	}
	
}
