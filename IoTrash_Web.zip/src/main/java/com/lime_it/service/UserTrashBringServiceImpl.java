package com.lime_it.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lime_it.dao.Member_TrashDAOImpl;
import com.lime_it.dao.TrashDAOImpl;
import com.lime_it.domain.Member_TrashVO;
import com.lime_it.domain.TrashVO;

@Service
public class UserTrashBringServiceImpl {

	@Autowired
	private TrashDAOImpl trashdao;
	
	@Autowired
	private Member_TrashDAOImpl Matchingdao;

	@Autowired
	private PushAlarmServiceImpl service;
	
	@Autowired
	private MatchUserTrashServiceImpl matchService;
	
	//Artik의 데이터를 가져와서 List 형식으로 저장
	public List<TrashVO> TrashBring(String user_Recognize) throws Exception {
		List<TrashVO> listTrashVO = new ArrayList<TrashVO>();
		List<Member_TrashVO> listMatchingVO = Matchingdao.getMatchingArtikValue(user_Recognize);
		for(Member_TrashVO vo : listMatchingVO){
			trashdao.getArtikData(vo.getArtik_ID()).setTrash_Location(vo.getTrash_Location());
			listTrashVO.add(trashdao.getArtikData(vo.getArtik_ID()));
		}
		return listTrashVO;
	}

	//푸시 알림을 위한 서비스
	public void forPushAlarm(String artik_ID) throws Exception {
		List<String> listUser_Recognize = Matchingdao.getMatchingRecognizes(artik_ID);
		for(String user_Recognize : listUser_Recognize){
			String trash_Location = matchService.BringtrashLocation(user_Recognize, artik_ID);
			service.pushAlarm(user_Recognize, trash_Location);
		}
	}
	
	

}
