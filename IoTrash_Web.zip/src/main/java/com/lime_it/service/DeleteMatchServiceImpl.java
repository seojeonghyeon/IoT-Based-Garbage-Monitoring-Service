package com.lime_it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lime_it.dao.Member_TrashDAOImpl;
import com.lime_it.domain.DeleteVO;
import com.lime_it.domain.MemberVO;

@Service
public class DeleteMatchServiceImpl {

	@Autowired
	private Member_TrashDAOImpl matchDAO;
	
	@Autowired
	LoginServiceImpl LoginService;
	
	public boolean deleteMatchValue(DeleteVO deleteVO) throws Exception{
		MemberVO vo = LoginService.updateUser(deleteVO.getUser_ID());
		return matchDAO.deleteMatchingValue(deleteVO, vo.getUser_Recognize());
	}
	
}
