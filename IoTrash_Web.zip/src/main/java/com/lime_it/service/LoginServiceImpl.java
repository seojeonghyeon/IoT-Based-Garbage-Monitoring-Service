package com.lime_it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lime_it.dao.MemberDAOImpl;
import com.lime_it.domain.MemberVO;

@Service
public class LoginServiceImpl {

	@Autowired
	MemberDAOImpl dao;

	public String appLogin(String user_ID, String user_Password) throws Exception {
		return LoginProcess(user_Password, dao.getMemberLogin(user_ID));
	}

	public String webLogin(String user_ID, String user_Password) throws Exception {
		return LoginProcess(user_Password, dao.getMemberLogin(user_ID));
	}

	public MemberVO updateUser(String user_ID) throws Exception {
		return dao.getMember(user_ID);
	}
	
	private String LoginProcess(String input_Password, String db_Password){
		if(input_Password.equals(db_Password))
			return "100";
		else
			return "200";
	}

}
