package com.lime_it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lime_it.dao.LogDAOImpl;
import com.lime_it.domain.LogActVO;
import com.lime_it.domain.LogArtikVO;

@Service
public class TrashLogServiceImpl {

	@Autowired
	LogDAOImpl dao;
	
	LogArtikVO vo;
	
	public void recodLog(String artik_ID, String actValue) throws Exception {
		System.out.println(artik_ID);
		System.out.println(actValue);
		String act_Number = null;
		List<LogActVO> listActVO = null;
		try {
			listActVO = dao.getActArtik();
		} catch (Exception e) {
			e.printStackTrace();
		}
		for(LogActVO ActVO : listActVO){
			if(ActVO.getAct_Content().equals(actValue))
				act_Number = ActVO.getAct_Number();
		}
		vo = new LogArtikVO();
		vo.setAct_Number(act_Number);
		vo.setAct_Time("");
		vo.setId("");
		vo.setArtik_ID(artik_ID);
		dao.insertLogforartikValue(vo);
	}
	
}
